export default class stackItem {
	constructor(value, next) {
		this.value = value;
		this.next = next;
	}
}